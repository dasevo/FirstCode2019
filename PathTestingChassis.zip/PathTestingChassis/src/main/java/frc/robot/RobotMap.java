package frc.robot;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.buttons.Button;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.Joystick;

public class RobotMap {

    private static RobotMap robotMap;

    private RobotMap() {
        
    }

    public static RobotMap getRobotMap() {
        if(robotMap == null) {
            robotMap = new RobotMap();
        }
        
        return robotMap;
    }

    public static final WPI_TalonSRX leftF = new WPI_TalonSRX(0);
    public static final WPI_TalonSRX leftR = new WPI_TalonSRX(1);
    public static final WPI_TalonSRX rightF = new WPI_TalonSRX(2);
    public static final WPI_TalonSRX rightR = new WPI_TalonSRX(3);

    public static final SpeedControllerGroup left = new SpeedControllerGroup(leftF, leftR);
    public static final SpeedControllerGroup right = new SpeedControllerGroup(rightF, rightR);

    public final DifferentialDrive drive = new DifferentialDrive(left, right);

    public static final Joystick leftStick = new Joystick(0);
    public static final Joystick rightStick = new Joystick(1);
    public static final Button buttonL1 = new JoystickButton(leftStick, 1);
    public static final Button buttonL2 = new JoystickButton(leftStick, 2);
    public static final Button buttonL3 = new JoystickButton(leftStick, 3);
    public static final Button buttonL4 = new JoystickButton(leftStick, 4);
    public static final Button buttonL5 = new JoystickButton(leftStick, 5);

    public double deadzone(double input) {
        if(Math.abs(input) > Constants.deadzone) {
            return input;
        }
        else {
            return 0;
        }
    }

    public double getLeftY() {
        return -deadzone(leftStick.getY());
    }

    public double getRightY() {
        return -deadzone(rightStick.getY());
    }

}